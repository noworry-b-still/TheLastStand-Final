using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyObject : MonoBehaviour
{
    // Start is called before the first frame update
    public float destroyDuration = 3;
    void Start()
    {
        Destroy(gameObject, destroyDuration);

    }

    // Update is called once per frame
    void Update()
    {

    }
}