using UnityEngine;

public class EnemyBehavior : MonoBehaviour
{
    private Transform player; // Reference to the player's transform
    public float movementSpeed = 5f; // Speed at which the enemy moves towards the player
    public float minDistance = 100f; // Minimum distance to maintain from the player
    public int health = 100;

    public static int enemyCount = 0;

    void Awake()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
    }

    void Start()
    {
        enemyCount++;
        print(enemyCount);
    }

    private void FixedUpdate()
    {
        if (player != null)
        {
            // Calculate the direction to the player
            Vector3 directionToPlayer = (player.position - transform.position).normalized;

            // Calculate the distance to the player
            float distanceToPlayer = Vector3.Distance(transform.position, player.position);

            if (distanceToPlayer < minDistance)
            {
                directionToPlayer *= -1; // Move away from the player
            }

            // Calculate the look rotation to face the player
            Quaternion lookRotation = Quaternion.LookRotation(directionToPlayer);
            // Smoothly rotate towards the player
            transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.fixedDeltaTime * 5f);

            // Move in the direction of the player (or away from the player)
            transform.position += transform.forward * movementSpeed * Time.fixedDeltaTime;
        }
    }

    private void IncreasePlayerScore(int score)
    {
        PlayerHealth.playerScore += score;
        Debug.Log("Player score : " + PlayerHealth.playerScore);
        PlayerHealth playerHealth = FindObjectOfType<PlayerHealth>();
        if (playerHealth != null)
        {
            playerHealth.SetScoreText();
        }
    }

    private void OnDestroy()
    {
        enemyCount--;
        print("from destroy " + enemyCount);
        IncreasePlayerScore(1);

        if (enemyCount <= 0)
        {
            FindObjectOfType<LevelManager>().LevelBeat();
            PlayerHealth.playerScore = 0;
        }
    }
}
